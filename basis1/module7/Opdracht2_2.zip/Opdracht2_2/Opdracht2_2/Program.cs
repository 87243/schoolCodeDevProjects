﻿using System;

namespace Opdracht2_2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Druk de tekst "Voer een woord in" af op het scherm
            //Lees de invoer in van de gebruiker

            //bovenstaande in totaal 3x;

            if (woord1.CompareTo(woord2) > 0 && woord1.CompareTo(woord3) > 0)
            {
                //woord1 is de grootste en moet achteraan komen

                //Controleer of woord2 groter is dan woord3

                //druk de woorden in de juiste volgorde af
            }
            else if (....) //doe nu hetzelde als hierboven, maar dan controleer je eerst of woord2 de grootste is
            {

            }
            ....   //Tot slot weet je dat getal3 de grootste is en handel je dit verder af
        }
    }
}
