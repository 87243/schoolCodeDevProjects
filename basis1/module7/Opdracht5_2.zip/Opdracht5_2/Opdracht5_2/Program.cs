﻿using System;

namespace Opdracht5_2
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Voer een zin in:");
            string zin = Console.ReadLine();
     
            string woord = "";
            int positie = 0;

            while (positie < .....)
            {
                int volgendeSpatie = zin.IndexOf(.. , ..);
                if (volgendeSpatie > 0)
                {
                    woord = ...
                }
                else
                {
                    woord = ...
                }
                //verwijder eventuele spaties
                //maak de eerste letter een hoofdletter en de andere kleine letters
                //druk het woord af
                //verhoog positie met ......
            }
        }
    }
}
