﻿using System;

namespace Opdracht3_2
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            int getal = 0;
            //declareer de andere variabelen die nodig zijn

            while (getal >= 0)
            {
                //Druk de tekst "Voer een getal in" af op het scherm
                //Lees de invoer in van de gebruiker
                //Zet de invoer om naar het juiste type variabele 

                if (getal > 0)
                {
                    //kleinste en grootste
                    if (aantal == 0)
                    {
                        //startwaarden bij eerste invoer
                        kleinste = getal;
                        grootste = getal;
                    }
                    //vergelijk het ingevoerde getal met de kleinste waarde
                    //stel de kleinste waarde opnieuw in (indien nodig)

                    //Doe hetzelfde voor de grootste waarde

                    //druk de kleinste waarde af
                    //druk de grootste waarde af

                    //tel het aantal getallen die ingevoerd zijn (in een aparte variabele)
                    //tel het getal bij het totaal op (totaal is een aparte variabele)
                    //bereken het gemiddelde en druk deze af

                }
            }
            Console.WriteLine("Bedankt voor het gebruiken van deze applicatie");
        }
    }
}
