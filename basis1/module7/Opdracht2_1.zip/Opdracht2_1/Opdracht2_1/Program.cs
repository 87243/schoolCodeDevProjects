﻿using System;

namespace Opdracht2_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Druk de tekst "Voer een getal in van 1 .. 12" af op het scherm
            //Lees de invoer in van de gebruiker
            //Zet de invoer om naar het juiste type variabele (indien nodig)

     
           
            //Als je deze opdracht oplost met if statements:
            if (getal == ...)   //Zet op de ... de juiste vergelijking
            {
                Console.WriteLine("januari");
            }
            else if (...) // Doe het bovenstaande voor alle andere maanden van het jaar
            {
               
            }


            //Als je deze opdracht oplost met een switch statement:
            switch (getal)
            {
                case 1:
                    Console.WriteLine("januari");
                    break;
                    // Doe het bovenstaande voor alle andere maanden van het jaar
            }


        }
    }
}
