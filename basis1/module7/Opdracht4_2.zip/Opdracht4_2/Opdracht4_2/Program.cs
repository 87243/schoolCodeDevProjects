﻿using System;

namespace Opdracht4_2
{
    class MainClass
    {
        public static void Main(string[] args)
		{
            int aantalX = 21;
			int aantalY = 15;
			for (int y = 0; y < aantalX; y++){     
				for (int x = 0; x < aantalX; x++){
					if (y <= aantalX / 2)
					{
						//top van de boom
						if (x < (aantalX / 2) - y || x > (aantalX / 2) + y)
						{
							Console.Write("* ");    
						}
						else
						{
							Console.Write("  ");     
						}
					}
					else
					{
						//stam
						if (x > (aantalX / 2) - (aantalX / 10) || x < (aantalX / 2) + (aantalX / 10))  
						{
							Console.WriteLine("* ");  
						}
						else
						{
							Console.Write("  ");
						}
					}
				}
				Console.WriteLine();
			}
		}
    }
}
