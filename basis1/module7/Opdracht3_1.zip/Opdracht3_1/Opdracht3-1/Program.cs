﻿using System;

namespace Opdracht31
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //Druk de tekst "Voer een getal in" af op het scherm
            //Lees de invoer in van de gebruiker
            //Zet de invoer om naar het juiste type variabele (indien nodig)


            
            for (int y = 0; ....) //maak deze for-lus verder af
            {
                for (int x = 0; ....) //maak deze for-lus verder af
                {
                    if (x == 0 || x == ... )    //Controleer hier voor welke x en y waarden er
                    {                           //een * afgedrukt moet worden (buitenkant van het vierkant)
                        Console.Write("* ");
                    }
                    else if( .... )             //Controleer hier voor welke x en y waarden de diagonalen      
                    {                           //getekend moeten worden
                        Console.Write("* ");
                    }
                    else
                    {
                        //druk een spatie af
                    }
                }
                //spring naar de volgende regel
            }
        }
    }
}
