﻿using System;

namespace Opdracht5_1
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //declareer hier drie variabelen waarin je het aantal A, E of I gaat opslaan
            
            Console.WriteLine("Voer een volledige zin in");
            string zin = Console.ReadLine();

            //zet de zin om in alleen kleine letters of alleen hoofdletters

            for (int i = 0; i < .....)
            {
                string letter = zin.Substring(.....);

                //is de letter een A dan ....
                //is de letter een E dan ....
                //is de letter een I dan ....
            }

            Console.WriteLine($"aantal keer A is: {aantalA}");
            Console.WriteLine($"aantal keer E is: {aantalE}");
            Console.WriteLine($"aantal keer I is: {aantalI}");
        }
    }
}
