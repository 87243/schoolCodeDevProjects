using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Opdracht_3_1.Pages{
    public class bestelModel : PageModel{
        public string naam = "naam";
        public string type = "type";
        public string beschrijving = "beschrijving";
        public double prijs = 0;
        public void OnGet(){
            naam = Request.Query["bank"];
            
            if(naam == "armour"){
                type = "2-zitsbank";
                beschrijving = "De Armour is een zeer voordelig geprijsde designbank met een eigenzinnige uitstraling. De Armour is verkrijgbaar in een groot aantal bekledingssoorten en kleuren.";
                prijs = 449.00;
            }
            if(naam == "baltica"){
                type = "2-zitsbank";
                beschrijving = "De Baltica is een tijdloos en duurzaam model met een prima zitcomfort tegen een zeer voordelige prijs. Met zijn mooie afwerking zal deze combinatie lang onderdeel uit maken van uw interieur en zult u er veel zitplezier aan beleven. Dit model Premium is leverbaar in 3-zits, 2-zits en 1-zits en daarnaast ook als hoekbank of loungebank.";
                prijs = 599.00;
            }
            if(naam == "bari"){
                type = "3-zitsbank";
                beschrijving = "De Bari is een L-shape bank. Een mooie en complete moderne toevoeging aan uw woonkamer. Daarnaast is het model Bari verkrijgbaar als 3-zits, 2-zits en 1-zits. Verkrijgbaar in verschillende kleuren.";
                prijs = 720.00;
            }
            if(naam == "canada"){
                type = "6-zitsbank";
                beschrijving = "De Canada is een tijdloos en duurzaam model met een enorm zitcomfort. Dit robuuste model is volledig naar uw gebruikswensen en de beschikbare ruimte in te delen door het samenvoegen van de verschillende combinaties en (hoek)elementen. Van 1-zits tot 3-zits en van hoekbank tot hocker is de Canada verkrijgbaar in een grote vari�teit aan bekledingssoorten en -kleuren.";
                prijs = 1299.00;
            }
            if(naam == "colorado"){
                type = "3-zitsbank";
                beschrijving = "Dat is nog eens bijzonder zitten! Het model Colorado is een eigenzinnig en romantisch model dat alle aandacht zal krijgen in uw woonkamer. Door het combineren van verschillende stoffen/kleuren van de sierkussens kunt u dit model uw eigen 'handtekening' geven. Dit model zelf en de sierkussens zijn in een grote vari�teit aan bekledingssoorten en -kleuren verkrijgbaar.";
                prijs = 799.00;
            }
            if(naam == "hawaii"){
                type = "5-zitsbank";
                beschrijving = "De Hawaii is een comfortabele loungebank (L-shape) met ongekende stylingsmogelijkheden door de verschillende formaten (losse) kussens (mogelijk in diverse kleuren/stofsoorten).";
                prijs = 999.99;
            }
        }
    }
}
