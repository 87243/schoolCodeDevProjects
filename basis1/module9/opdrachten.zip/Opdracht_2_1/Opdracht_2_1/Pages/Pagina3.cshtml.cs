﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Opdracht_2_1.Pages{
    public class Pagina3Model : PageModel{
        //Zet hier een public variabele voor de uitkomst
        public int result = 0;
        

        public void OnGet(){
            //lees de twee meegestuurde parameters in
            string getal1String = Request.Query["getal1"];
            string getal2String = Request.Query["getal2"];
            int getal1 = 0;
            int getal2 = 0;
            string wat = Request.Query["wat"];
            if(getal1String != null && getal2String != null){    //controleer of de parameters gevuld zijn
                getal1 = int.Parse(getal1String);  //bepaal de waarde voor getal 1
                //doe hetzelfde voor getal 2
                getal2 = int.Parse(getal2String);
            }
            //bereken de uitkomst
            if(wat == "optellen"){
                result = getal1 + getal2;
            }
            if(wat == "vermenigvuldigen"){
                result = getal1 * getal2;
            }
            if(wat == "delen"){
                result = getal1 / getal2;
            }
        }
    }
}
