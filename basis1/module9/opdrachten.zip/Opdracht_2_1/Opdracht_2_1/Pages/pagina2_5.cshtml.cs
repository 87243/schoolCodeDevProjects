using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Opdracht_2_1.Pages{
    public class pagina2_5Model : PageModel{
        public int getal1;
        public int getal2;
        public void OnGet(){
            string getal1String = Request.Query["getal1"];
            string getal2String = Request.Query["getal2"];
            if (getal1String != null)
            {
                getal1 = int.Parse(getal1String);
            }
            if (getal2String != null)
            {
                getal2 = int.Parse(getal2String);
            }
        }
    }
}
