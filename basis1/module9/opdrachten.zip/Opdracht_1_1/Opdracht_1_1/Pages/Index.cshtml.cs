﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;

namespace Opdracht_1_1.Pages
{
    public class IndexModel : PageModel
    {
        //Hieronder is een property aangemaakt voor mijnNaam;
        public string mijnNaam;

        //Maak hier ook property's aan voor mijnStudentnummer en mijnLeeftijd
        public string mijnStudentnummer;
        public string mijnLeeftijd;
        
        public void OnGet()
        {
            //hieronder lees de meegestuurde parameter mijnNaam
            string naam = Request.Query["mijnNaam"];
            
            //hieronder controleer je of die inderdaad gevuld is (dus gestuurd was)
            if (naam != null){
                //vul de property met de meegestuurde waarde
                mijnNaam = naam;
            }
            
            //hieronder lees de meegestuurde parameter mijnStudentnummer
            string studentnummer = Request.Query["mijnStudentnummer"];
            
            //maak hier de code verder af voor mijnStudentnummer en mijnLeeftijd
            if (studentnummer != null){
                //vul de property met de meegestuurde waarde
                mijnStudentnummer = studentnummer;
            }
            string leeftijd = Request.Query["mijnLeeftijd"];
            if (leeftijd != null){
                //vul de property met de meegestuurde waarde
                mijnLeeftijd = leeftijd;
            }
        }
    }
}